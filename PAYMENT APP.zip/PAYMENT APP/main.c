#include <stdio.h>
#include <stdlib.h>

#include "APPLICATION/app.h"


int main() {

	while (1)
	{
		appStart();

	}
	

}


	
