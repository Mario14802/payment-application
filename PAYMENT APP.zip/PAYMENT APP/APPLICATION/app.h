#ifndef APP_H
#define APP_H

#include "../STD_TYPES.h"
#include "../SERVER/server.h"




void appStart(void);//SALE

#endif /* APP_H */


